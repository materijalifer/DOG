% skripta za 11 poglavlje

load samo
[bf,p]=size(a_m);   %koeficijenti nalaze u matrici a_m sa bf redaka i p+1 
p = p-1;            %stupac, gdje je bf ukupni broj okvira, a p red predikcije

a_m=a_m(:,2:p+1);   % prvi je jednak 1 na obje strane

a_m_min=min(a_m);   % p-dimenzionalni redak s najmanjom vrijednosti svakog
                    % a-koeficijenta
a_m_max=max(a_m);   % p-dimenzionalni redak s najvecom vrijednosti svakog
                    % a-koeficijenta
a_m_raspon=a_m_max-a_m_min; % raspon svakog koeficijenta
% provedi normalizaciju
a_m_norm=(a_m-(ones(bf,1)*a_m_min))./(ones(bf,1)*(a_m_raspon*(1+eps)));

%Sada provedi kvantizaciju svih koeficijenata sa b bita, mno�enjem sa 2b i 
%odsijecanjem prema dolje:
b = 7;
a_m_cijel=floor(a_m_norm*2^b);

% Postupak dekodiranja se provodi ovako
a_m_norm_dek=(a_m_cijel+0.5)/(2^b);
% Denormalizacija 
a_m_dek=a_m_norm_dek.*(ones(bf,1)*a_m_raspon)+ (ones(bf,1)*a_m_min);

% Rezultate ovog postupka mo�emo usporediti s originalnim koeficijentima.
% figure
% plot([1:100],a_m(1:100,1),'b--',[1:100],a_m_dek(1:100,1),'b',...
%      [1:100],a_m(1:100,2),'g--',[1:100],a_m_dek(1:100,2),'g',...
%      [1:100],a_m(1:100,3),'r--',[1:100],a_m_dek(1:100,3),'r');

unst = zeros(0,bf);
for i = 1:bf,
    okv = i;             % Odaberi jedan okvir
    a =[1 a_m(okv,:)];    % Izdvoji originalne koeficijente tog okvira
    ak=[1 a_m_dek(okv,:)];% Izdvoji kvatizirane koeficijente tog okvira
    
    % Izra�unajmo amplitudno frekvencijske karakterisitke tih filtara u 512
    % jednoliko razmaknutih frekvencijskih to�aka od 0 do ? (tj. od 0 do fs/2):
    h= 20*log10(abs(freqz(1,a,512)));  % Originalna frekv. karak. u dB
    hk=20*log10(abs(freqz(1,ak,512))); % Kvatizirana frekv. karak. u dB
    
    % Prikaz originalna crtkanom linijom, kvantizirana punom linijom
    % figure
    % plot([0:511]/512*fs/2,h,'b--', [0:511]/512*fs/2,hk,'b');
    
    % Ovo izobli�enje se mo�e odrediti i numeri�ki u Matlabu na osnovu otipkanih
    % frekvencijskih karakterisitka h i hk, zamjenom integrala sa sumom:
    SD2 = mean((h-hk).^2);
    
    % korijeni
    r=roots(a);
    rk=roots(ak);
    % priaz korijena
    %plot(real(r),imag(r),'+',real(rk),imag(rk),'*',...
    %     sin(2*pi*[0:200]/200), cos(2*pi*[0:200]/200)); axis('square');
    
    % Sacuvaj samo korijene u gornjoj poluravnini (kut>0)
    r=r(find(angle(r)>0));          % za originale korijene
    rk=rk(find(angle(rk)>0));       % za korijene kvantiziranog H(z)
    r_mod=abs(r); r_ang=angle(r);   % Odredi modul i kut svih korijena
    rk_mod=abs(rk); rk_ang=angle(rk);
    
    % Sortiraj korjene po rastucim kutevima
    [sr_ang, inr]=sort(r_ang); sr_mod =r_mod(inr);
    [srk_ang, inrk]=sort(rk_ang); srk_mod=rk_mod(inrk);
    % Prikazi tablicu modula i kuteva (prije i poslije kvant.)
%     disp ([[1:5]' sr_ang sr_mod srk_ang srk_mod]);
    
    % Preracunaj kuteve i module u cent. frekv. i sirine formanata
    sr_f =sr_ang/pi*fs/2; sr_bw =-log(sr_mod)/pi*fs;
    srk_f=srk_ang/pi*fs/2; srk_bw=-log(srk_mod)/pi*fs;
    % Prikazi tablicu cent.frekv. i sirina formanata (prije i poslije kvant.)
%     disp ([[1:5]' round([sr_f sr_bw srk_f srk_bw])]);
    
    % BRoj nestabilnih parova
    unst(i)=length(find(abs(rk)>1))/2;
end;
% rezultat
unst = unst';

% plot(unst);
stem (unst,'Marker','none')
post_unst=mean(unst>0)*100

