% skripta za 12 poglavlje

[sig,fs]=wavread('sa2.wav');
% sig - vektor koji sadr�i uzorke govornog signala
% fs - frekvencija otipkavanja.
% Broj uzoraka signala koje �emo izdvojiti za analizu
N=512;

f=[-N/2:N/2-1]/N*fs;
t=[-N/2:N/2-1]/fs*1000;

% Naredbom size(dat) odre�ujemo ukupni broja uzoraka u signalu koji iznosi 13780
% za ovaj primjer.
% size(sig,1)
for i = 1: floor(size(sig,1)/512)-1
%     i
    %  10000 je zvucni 'a', a 4000 je bezvucni 's'
    % sig_part=sig(10000:10000+(N-1));
    sig_part=sig(i*512:i*512+(N-1));
    % figure                          % Izdvojeni dio signala
    % plot(t,sig_part);
    % title('Zvucni govorni signal');
    
    % figure                          % Blackman i signal
    % sig_part=sig_part.*blackman(N);
    % plot(t,sig_part);
    % title('Zvucni govorni signal pomnozen vremenskim otvorom');
    spect=fft(sig_part);
    mod_spect=log(abs(spect));
    
    % f =  f(1:256);
    % temp =  [mod_spect(N/2+1:N); mod_spect(1:N/2)]
    % figure                          % Prikaz logaritma modula spektra
    % plot(f, [mod_spect(N/2+1:N); mod_spect(1:N/2)]);
    % title('Prikaz logaritma modula spektra');
    
    cepst=ifft(mod_spect);
    cepst=real(cepst);
    
    % figure % Dobiveni kepstar predstavlja izlaz sustava za homomorfnu dekonvoluciju
    % plot(t,[cepst(N/2+1:N); cepst(1:N/2)]);
    % title('Dobiveni kepstar predstavlja izlaz sustava za homomorfnu dekonvoluciju');
    t0=2.5e-3;
    t0_ind=round(t0*fs);
    
    ltp=cepst;
    ltp(t0_ind+2:N-t0_ind)=zeros(1,N-2*t0_ind-1);
    htp=cepst-ltp;
    
    % figure                          % Prikaz LTP dijela
    % plot(t,[ltp(N/2+1:N) ;ltp(1:N/2)]);
    % title('Prikaz LTP dijela');
    
    % figure                        % Prikaz HTP-a provodimo analogno:
    % plot(t,[htp(N/2+1:N); htp(1:N/2)]);
    % title('Prikaz HTP dijela');
    
    ltp_spect=fft(ltp);
    % htp_spect=fft(htp);
    
    ltp_spect=real(ltp_spect);
    % htp_spect=real(htp_spect);
    the_matrica(i,:) = [ltp_spect(N/2+1:N); ltp_spect(1:N/2)];
end;

 pcolor(the_matrica)