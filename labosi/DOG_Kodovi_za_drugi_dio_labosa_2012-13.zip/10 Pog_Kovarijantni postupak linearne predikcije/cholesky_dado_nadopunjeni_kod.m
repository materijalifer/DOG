function [al,y,d]=cholesky_dado(fi,psi)

p=length(psi);
if max(abs(size(fi)-[p p])),
    error('Wrong dimensions');
end;

% Elementi dijagonalne matrice D
d=zeros(p,1);
% Pomocna matrica V
v=eye(p);

% Nadji prvi element od D(1,1) i prvi stupac matrice V (ispod dijagonale)
d(1)=fi(1,1);
v(2:p,1)=fi(2:p,1)/d(1);

% Za ostale elemente D(k,k) i ostale stupce matrice V
for k=2:p,
    i=[k+1:p];   % indeksi pod-dijagonalnih redaka
    j=[1:k-1];
    d(k)=fi(k,k)-(v(k,j).^2)*d(j);                    % nadji D(k,k)
    v(i,k)=(fi(i,k)-v(i,j)*diag(d(j))*v(k,j)')/d(k);  % i V(i,k)
end;

% Nadjimo pomocno rjesenje y supstitucijom unaprijed
y=zeros(p,1);
y(1)=psi(1); % prvi clan
for i=2:p,
    y(i)=psi(i) - v(i,1:i-1)*y(1:i-1);
end;

% Podijelimo y sa dijagonalnim elementima od D
y2=y./d;

% Nadjimo konacno rjesenje al supstitucijom unazad
al=zeros(p,1);
al(p)=y2(p); % zadnji clan
for i=p-1:-1:1,
    al(i)=y2(i)-v(i+1:p,i)'*al(i+1:p);
end;

