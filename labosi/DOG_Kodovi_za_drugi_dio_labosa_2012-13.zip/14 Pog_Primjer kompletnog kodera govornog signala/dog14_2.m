param(1)=512;     % Broj uzoraka frame-a
param(2)=110;     % korak frame-ova izrazen u broju uzoraka
param(3)=80;      % Donja granicna frekvecija u Hz (-3 dB)
param(4)=0.9375;  % faktor za pre-emphasis ili 0 ako je bez
param(5)=3e-3;    % minimalni ocekivani pitch period
param(6)=15e-3;   % maksimalni ocekivani pitch period
param(7)=0.175;   % v/uv prag
param(8)=1;       % HTP Cepstrum interpolation (1=Yes)
param(9)=1;       % Median-Linear Pitch filtering (1=Yes)
param(10)=12;     % LPC predictor order

analy('glas.wav','glas.mat',param,0);
synt('glas.mat','glas_no.wav',1,0);
load glas;
bb=max(size(pp));

En_m_v(1:2:2*bb,:)=En_m;
En_m_v(2:2:2*bb,:)=En_m;

a_m_v(1:2:2*bb,:)=a_m;
a_m_v(2:2:2*bb,:)=a_m;

en_v(1:2:2*bb,:)=en;
en_v(2:2:2*bb,:)=en;

k_m_v(1:2:2*bb,:)=k_m;
k_m_v(2:2:2*bb,:)=k_m;

pp_v(1:2:2*bb,:)=pp;
pp_v(2:2:2*bb,:)=pp;

v_v(1:2:2*bb,:)=v;
v_v(2:2:2*bb,:)=v;

r_m_v(1:2:2*bb,:)=r_m;
r_m_v(2:2:2*bb,:)=r_m;

En_m=En_m_v;
a_m=a_m_v;
en=en_v;
k_m=k_m_v;
pp=pp_v;
v=v_v;
r_m=r_m_v;

clear En_m_v a_m_v en_v k_m_v pp_v v_v r_m_v;
save glas2
synt('glas2.mat','glas_du.wav',1,0);

load glas;
bb=max(size(pp));
En_m=En_m(1:2:bb,:);
a_m=a_m(1:2:bb,:);
en=en(1:2:bb,:);
k_m=k_m(1:2:bb,:);
pp=pp(1:2:bb,:);
v=v(1:2:bb,:);
r_m=r_m(1:2:bb,:);
save glas2
synt('glas2.mat','glas_kr.wav',1,0);

load glas;
pp=pp/2;
save glas;
synt('glas.mat','glas_hi.wav',1,0);
load glas;
pp=pp*4;
save glas;
synt('glas.mat','glas_lo.wav',1,0);
