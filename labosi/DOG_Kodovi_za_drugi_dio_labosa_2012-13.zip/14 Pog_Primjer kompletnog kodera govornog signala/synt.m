function synt(matfile,synfile,interp,debug)
% function synt(matfile,synfile,interp,debug)
%
% Program za sintezu govornog signala na osnovu
% parametara dobivenih LPC analizom. Nakon sinteze
% radi se de-emphasis s istim alfa faktorom koji
% je koristen kod analize
%
% Ulazni podaci:
%        matfile ..... string s nazivom ulaznog mat file-a
%        synfile ..... string s nazivom izlaznog wav file-a
%        interp ...... ako je interp==1 radi se 'k' interpolacija
%        debug ....... ako je debug==1 crtaju se slike
%
% ... u matfile datoteci se moraju nalaziti slijedece
%     varijable potrebne za sintezu :
%
%   1.  param ....... vektor parametara koristenih za analizu
%   2.  fs .......... frekvencija otipkavanja
%   3.  pp .......... pitch period
%   4.  v ........... v/uv (1/0)
%   5.  k_m ......... matrica s 'k' parametrima LPC analze
%   6.  En_m ........ vektor rezidualne energije nakon LPC-a
%
% Format vektora param i tipicne vrijednosti:
% (sa * su oznaceni oni parametri koji su potrebni kod sinteze)
%
% * param(1)=512;     % Broj uzoraka frame-a
% * param(2)=110;     % korak frame-ova izrazen u broju uzoraka
%   param(3)=80;      % Donja granicna frekvecija u Hz (-3 dB)
% * param(4)=0.9375;  % faktor za pre-emphasis ili 0 ako je bez
%   param(5)=3e-3;    % minimalni ocekivani pitch period
%   param(6)=15e-3;   % maksimalni ocekivani pitch period
%   param(7)=0.175;   % v/uv prag
%   param(8)=1;       % HTP Cepstrum interpolation (1=Yes)
%   param(9)=1;       % Median-Linear Pitch filtering (1=Yes)
% * param(10)=12;     % LPC predictor order
%
% Izlaz funkcije nalazi se u izlaznoj wav datoteci (synfile)
%

% odz mora biti globalan, da ga ne moramo prenasati u wavwrit2
global odz;

t1=clock;

komanda=['load ' matfile ];
eval(komanda);
clear r_m en;
read_time=etime(clock,t1);

N=param(1);
kor=param(2);
alfa=param(4);
p=param(10);

bf=max(size(En_m));

fprintf('\n Input file      : ')
fprintf(wavefile);
fprintf('\n LPC param. file : ')
fprintf(matfile);
fprintf('\n Output file     : ')
fprintf(synfile);
fprintf('\n No. of samples  : %d',bf*kor);
fprintf('\n Sampling rate   : %8.2f Hz',fs);
fprintf('\n Sequence lenght : %8.2f sec',bf*kor/fs);
fprintf('\n Syntesis frame  : %d samples = %5.2f msec',...
         N,1000*N/fs);
fprintf('\n Frame step      : %d samples = %5.2f msec',...
         kor,1000*kor/fs);
fprintf('\n Frame rate      : %8.2f Hz',fs/kor);
fprintf('\n No. of frames   : %d',bf);
fprintf('\n LPC polynomial order          : %d',p);
fprintf('\n Interpolation of k-param.     : ');
if (interp==1),
  fprintf('YES');
else,
  fprintf('NO');
end;
fprintf('\n Speach spectrum de-emphasis   : ');
if (alfa>0),
  fprintf('YES, by alfa=%6.4f',alfa);
else,
  fprintf('NO');
end;

fprintf('\n\n\n Readnig done');
fprintf(' ........ %7.2f sec',read_time);

t1=clock;

% Formiraj vektor s izlaznim signalom
odz=zeros(bf*kor,1);

% Ovo su stanja LPC filtra
Z=zeros(1,p);

v=[v;0];
poin=0;

if (interp==1),

for i=1:bf,
  if (v(i)==0), 
     pob=rand(kor,1)*2-1;
     no=norm(pob);
     pob=pob/no*sqrt(En_m(i));
     [Y,Z]=filter(1,a_m(i,:),pob,Z);
     odz((i-1)*kor+1:i*kor)=Y;
     poin=i*kor;
  else,
     ind=[];
     while (poin<i*kor),
        ind=[ind floor(poin)-(i-1)*kor];
        poin=poin+pp(i);
     end;
     poin=min(poin,kor*bf-1);
     bp=max(size(ind));
     if (bp>0),
        if (v(i+1)==1),
          ind=[ind floor(poin)-(i-1)*kor];
          for j=1:bp,
            a=k2a(k_m(i,:)*(1-ind(j)/kor)+k_m(i+1,:)*ind(j)/kor);
            [Y,Z]=filter(1,a,...
              [sqrt(En_m(i)/bp); zeros(ind(j+1)-ind(j)-1,1)],Z);
            odz((i-1)*kor+ind(j)+1:(i-1)*kor+ind(j+1))=Y;
          end;
        else,
          ind=[ind kor];
          for j=1:bp,
            [Y,Z]=filter(1,a_m(i,:),...
              [sqrt(En_m(i)/bp); zeros(ind(j+1)-ind(j)-1,1)],Z);
            odz((i-1)*kor+ind(j)+1:(i-1)*kor+ind(j+1))=Y;
          end;
        end;
     end;                
  end;
end;

else,

for i=1:bf,
  if (v(i)==0), 
     pob=rand(kor,1)*2-1;
     no=norm(pob);
     pob=pob/no*sqrt(En_m(i));
     [Y,Z]=filter(1,a_m(i,:),pob,Z);
     odz((i-1)*kor+1:i*kor)=Y;
     poin=i*kor;
  else,
     ind=[];
     while (poin<i*kor),
        ind=[ind floor(poin)-(i-1)*kor];
        poin=poin+pp(i);
     end;
     bp=max(size(ind));
     pob=zeros(kor,1);
     if (bp>0),
        pob(ind+1)=sqrt(En_m(i)/bp)*ones(bp,1);
     end;
     [Y,Z]=filter(1,a_m(i,:),pob,Z);
     odz((i-1)*kor+1:i*kor)=Y;
  end;
end;

end;

synt_time=etime(clock,t1);
fprintf('\n Synth.  done');
fprintf(' ........ %7.2f sec',synt_time);

if (debug==1),
    plot([0:bf*kor-1]/fs,odz);
    title('Synthetic speach signal');
    xlabel('Time (sec)');
    ylabel('Amplitude');
    pause;
end;

if (alfa>0),
    % De-emphasis
    t1=clock;

    Z=0;
    for i=1:bf
    [odz((i-1)*kor+1:i*kor),Z]=...
      filter(1,[1 -alfa],odz((i-1)*kor+1:i*kor),Z);
    end;

    deem_time=etime(clock,t1);
    fprintf('\n De-emph.done');
    fprintf(' ........ %7.2f sec',deem_time);

    if (debug==1),
        plot([0:bf*kor-1]/fs,odz);
        title('Synthetic speach signal (after de-emphasis)');
        xlabel('Time (sec)');
        ylabel('Amplitude');
        pause;
    end;
else,
    deem_time=0;
end;

t1=clock;
ma_am=0;
for i=1:bf
  m=max(abs(odz((i-1)*kor+1:i*kor)));
  ma_am=max(ma_am, m);
end;
for i=1:bf
  odz((i-1)*kor+1:i*kor)=...
    round(odz((i-1)*kor+1:i*kor)/ma_am*32767)/32768;
end;
quan_time=etime(clock,t1);
fprintf('\n Quant.  done');
fprintf(' ........ %7.2f sec',quan_time);

t1=clock;
wavwrite(odz,fs,16,synfile);
save_time=etime(clock,t1);
fprintf('\n Saving  done');
fprintf(' ........ %7.2f sec',save_time);

tot_time=read_time+...
         synt_time+...
         deem_time+...
         quan_time+...
         save_time;

fprintf('\n Total time      ');
fprintf(' .... %7.2f sec',tot_time);
