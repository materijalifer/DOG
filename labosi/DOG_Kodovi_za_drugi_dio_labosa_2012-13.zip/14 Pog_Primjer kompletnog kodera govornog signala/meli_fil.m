function pp_fil=meli_fil(pp)
%
% Programcic koji ce provesti nelinearno peglanje
% informacije o pitch periodu
% 
% koristi se kombinacija MEDIAN i LINEARNOG filtriranja
%
% .... w(n) = S[x(n)] + S[R[x(n)]]
% 
% vidi DPSS, Rabiner, Schafer pp 158

% ulaz pp, bf
% pp ... vektor s pitch periodom

bf=max(size(pp));

N_med=5;               % Samo neparni median dozvoljen

% linearni filter

ham_fil=[.25 .5 .25];  % Samo parni red filtra ...
                       % neparni broj koeficijenata
N_lin=max(size(ham_fil));

% Kasnjenje koje uzrokuje median filter;
dela_med=(N_med-1)/2;

% Kasnjenje koje uzrokuje median filter;
dela_lin=(N_lin-1)/2;

% Median filtracija Pitch perioda

mf_pp=[];

for i=1:bf-(N_med-1),
  blok=pp(i:i+(N_med-1));
  blok=sort(blok);
  mf_pp(i)=blok((N_med+1)/2);
end;

% Prosirenje zbog Low Pass-a
mf_pp=[mf_pp mf_pp(bf-(N_med-1))*ones(1,dela_lin)];

mflf_pp=filter(ham_fil,1,mf_pp);

% Izbaci dio koji odgovara utitravanju filtra
mflf_pp(1:dela_lin)=[];

% Z predstavlja R[x(n)] ... cupavi dio
z=pp(dela_med+1:dela_med+bf-N_med+1)-mflf_pp;

% .... idemo sada taj cupavi dio obraditi na isti
% nacin da vidimo da li je u njemu ostalo sto od
% glatkog dijela

mf_z=[];

% Prvo ide MEDIAN filtracija cupavog dijela

for i=1:bf-2*(N_med-1),
  blok=z(i:i+N_med-1);
  blok=sort(blok);
  mf_z(i)=blok((N_med+1)/2);
end;

% Prosirenje zbog Low Pass-a
mf_z=[mf_z mf_z(bf-2*(N_med-1))*ones(1,dela_lin)];

mflf_z=filter(ham_fil,1,mf_z);
mflf_z(1:dela_lin)=[];

% sada glatkom dijelu (mflf_pp) dodaj
% glatki dio dobiven iz cupavog dijela (mflf_z)

w=mflf_pp(dela_med+1:dela_med+bf-2*(N_med-1))+mflf_z;

% Sada treba jos konacno vratiti stvar na originalnu
% duzinu .... (bf)

pp_fil=[ones(1,2*dela_med)*w(1) w ...
        ones(1,2*dela_med)*w(bf-2*(N_med-1))]; 