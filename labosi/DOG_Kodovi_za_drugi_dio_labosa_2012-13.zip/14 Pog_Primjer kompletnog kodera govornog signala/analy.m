function analy(wavefile,outfile,param,debug)
% function analy(wavefile,outfile,param,debug)
%
% Funkcija koja radi High-pass filtering ulaznog signala,
% preemphasis, voicing / unvoicing determination,
% Cepstrum pitch estimation, pitch median/linear filtering i 
% LPC analizu
%
% Ulazni podaci:
%        wavefile .... string s nazivom ulaznog wav file-a
%        outfile ..... string s nazivom izlaznog mat file-a
%        param ....... vektor s potrebnim parametrima analize
%        debug ....... ako je debug==1 crtaju se slike
%
% Format vektora param i tipicne vrijednosti:
%
% param(1)=512;     % Broj uzoraka frame-a
% param(2)=110;     % korak frame-ova izrazen u broju uzoraka
% param(3)=80;      % Donja granicna frekvecija u Hz (-3 dB)
% param(4)=0.9375;  % faktor za pre-emphasis ili 0 ako je bez
% param(5)=3e-3;    % minimalni ocekivani pitch period
% param(6)=15e-3;   % maksimalni ocekivani pitch period
% param(7)=0.175;   % v/uv prag
% param(8)=1;       % HTP Cepstrum interpolation (1=Yes)
% param(9)=1;       % Median-Linear Pitch filtering (1=Yes)
% param(10)=12;     % LPC predictor order
%
% Izlaz funkcije nalazi se u izlaznoj mat datoteci (outfile)
% u kojoj su pohranjene slijedece varijable:
%
%   1.  wavefile .... String s nazivom ulaznog wav file-a
%   2.  param ....... vektor parametara koristenih za analizu
%   3.  fs .......... frekvencija otipkavanja
%   4.  pp .......... pitch period
%   5.  v ........... v/uv (1/0)
%   6.  en .......... Cepstralni koef C0
%   7.  a_m ......... matrica s 'a' parametrima LPC analze
%   8.  k_m ......... matrica s 'k' parametrima LPC analze
%   9.  r_m ......... matrica s autokorelac. ulaznog signala
%   10. En_m ........ vektor rezidualne energije nakon LPC-a

N=param(1);
kor=param(2);
fd=param(3);
alfa=param(4);
pitch_min=param(5);
pitch_max=param(6);
prag=param(7);
cep_int=param(8);
med_lin=param(9);
p=param(10);

load htp_ko_6;

% Ovo je varijabla za pohranu ulaznog signala i ona je
% proglasena globalnom, tako da se izbjegne 'kopiranje'
% te ogromne varijable prilikom poziva funkcije 'Noll_new'

global dat; 

t1=clock;
[dat,fs]=wavread(wavefile);
dat=dat';
read_time=etime(clock,t1);

w=hamming(N);
bf=floor((max(size(dat))-N)/kor)+1;

fprintf('\n Input file      : ')
fprintf(wavefile);
fprintf('\n No. of samples  : %d',max(size(dat)));
fprintf('\n Sampling rate   : %8.2f Hz',fs);
fprintf('\n Sequence lenght : %8.2f sec',max(size(dat))/fs);
fprintf('\n Analysys frame  : %d samples = %5.2f msec',...
         N,1000*N/fs);
fprintf('\n Frame step      : %d samples = %5.2f msec',...
         kor,1000*kor/fs);
fprintf('\n Frame rate      : %8.2f Hz',fs/kor);
fprintf('\n No. of frames   : %d Hz',bf);
fprintf('\n Minimum pitch   : %5.2f ms',pitch_min*1000);
fprintf('\n Maximum pitch   : %5.2f ms',pitch_max*1000);
fprintf('\n v/uv treshold   : %5.3f',prag);
fprintf('\n Median/linear pitch filtering : ');
if (med_lin==1),
  fprintf('YES');
else,
  fprintf('NO');
end;
fprintf('\n Cepstrum interpolation        : ');
if (cep_int==1),
  fprintf('YES');
else,
  fprintf('NO');
end;
fprintf('\n LPC polynomial order          : %d',p);
fprintf('\n Speach spectrum pre-emphasis  : ');
if (alfa>0),
  fprintf('YES, by alfa=%6.4f',alfa);
else,
  fprintf('NO');
end;

fprintf('\n\n\n Readnig done');
fprintf(' ........ %7.2f sec',read_time);

t1=clock;

% Butterworth HP filter 8 reda, za otklanjanje
% nisko-frekvencijskih komponenti

[b_bu,a_bu]=butter(8,fd/fs*2,'high');

% Ovo je potrebno jer novi Matlab nezna izracunati
% filter
[h,om]=freqz(b_bu,a_bu,1024);
b_bu=b_bu/max(abs(h));

% Ako se radi pre-emphasis ... jednostavno konvolviraj
% brojnik HP filtra i FIR pre-emphasis filter

if (alfa>0),
  b_bu=conv(b_bu,[1 -alfa]);
end;

dat=filter(b_bu,a_bu,dat);
%dat=filter([1 -alfa],1,dat);

fprintf('\n HP filtering done');
hpfilt_time=etime(clock,t1);
fprintf(' ... %7.2f sec',hpfilt_time);

if (debug==1),
  [h,om]=freqz(b_bu,a_bu,1024);
  plot(om/pi/2*fs,20*log10(abs(h)+1e-6));...
    axis([0 fs/2 -60 10]);
  title('High Pass Butterworth filter / pre-emph');
  xlabel('Frekvecija (Hz)');
  ylabel('dB');
  grid;
  pause;

  plot([0:max(size(dat))-1]/fs,dat);
  title('HP-Filtrirani ulazni signal');
  xlabel('Vrijeme (sec)');
  ylabel('Amplituda');
  pause;

end;


% Ovo je sada za ozbiljno

t1=clock;

[en v pp]=...
noll_new(N,fs,kor,pitch_min,pitch_max,...
prag,koef_mean,cep_int);

fprintf('\n Pitch est.  done');
pitch_time=etime(clock,t1);
fprintf(' .... %7.2f sec',pitch_time);

if (debug==1),

  plot([0:bf-1]*kor/fs,[v.*pp/fs*1000 en+5]);
  title('Pitch period & Cepstrum C0');
  xlabel('Vrijeme (sec)');
  ylabel('Pitch (ms), C0 (log)');
  pause;

end;

if (med_lin==1),
  
  t1=clock;

  pp_fil=(meli_fil((v.*pp)'))';
  v_fil=v.*(pp_fil>floor(pitch_min*fs));

  fprintf('\n Pitch filt. done');
  pitch_fil_time=etime(clock,t1);
  fprintf(' .... %7.2f sec',pitch_fil_time);

  if (debug==1),
    plot([0:bf-1]*kor/fs,[v.*pp/fs*1000 ...
          v_fil.*pp_fil/fs*1000 en+5]);
    title('Pitch period prije i nakon MED-LIN filtracije');
    xlabel('Vrijeme (sec)');
    ylabel('Pitch (ms), C0 (log)');
    pause;
  end;

  pp=pp_fil;
  v=v_fil;

else,
  pitch_fil_time=0;
end;

% POCETAK LPC ANALIZE

% Matrice za pohranu a i k LPC parametara, za autokorelaciju
% samog signala (r_m), kao i rezidualnu energiju (En_m)

t1=clock;

a_m=zeros(bf,p+1);
k_m=zeros(bf,p);
r_m=zeros(bf,p+1);
En_m=zeros(bf,1);

R=zeros(1,p+1);

for broj=1:bf,
  sw=dat((broj-1)*kor+1:(broj-1)*kor+N).*w';
  for k=0:p, R(k+1)=sw(1:N-k)*sw(k+1:N)'; end;
  r_m(broj,:)=R;
  alf=zeros(p,p);
  E(1)=R(1);
  alf(1,1)=R(2)/E(1);
  E(2)=(1-alf(1,1)*alf(1,1))*E(1);
  for i=2:p,
    alf(i,i)=(R(i+1)-alf(i-1,1:i-1)*R(i:-1:2)')/E(i);
    alf(i,1:i-1)=alf(i-1,1:i-1)-alf(i,i)*alf(i-1,i-1:-1:1);
    E(i+1)=(1-alf(i,i)*alf(i,i))*E(i);
  end;
  En_m(broj)=E(p+1);
  a_m(broj,:)=[1 -alf(p,:)];
  k_m(broj,:)=-diag(alf)';
%  if (broj==15), keyboard; end;
end;

fprintf('\n LPC anal.   done');
lpc_time=etime(clock,t1);
fprintf(' .... %7.2f sec',lpc_time);

if (debug==1),

  plot([0:bf-1]*kor/fs,[en 0.5*log(En_m)])
  title('Cepstrum C0, 0.5*ln(En)');
  xlabel('Vrijeme (sec)');
  ylabel('(log)');
  pause;

  plot([0:bf-1]*kor/fs,k_m);
  title('LPC refleksioni (k) koeficijenti kroz vrijeme');
  xlabel('Vrijeme (sec)');
  ylabel('Amplituda');
  pause;

  plot([0:bf-1]*kor/fs,a_m);
  title('LPC a koeficijenti kroz vrijeme');
  xlabel('Vrijeme (sec)');
  ylabel('Amplituda');
  pause;

  plot(k_m(:,1),k_m(:,2),'o');axis([-1 1 -1 1]);
  title('refleksioni (k) koeficijenti ... k1/k2 scatter');
  xlabel('k1');
  ylabel('k2');
  pause;

end;

% KRAJ

t1=clock;

komanda=['save ' outfile ...
         ' wavefile param fs pp v en a_m k_m r_m En_m'];
eval(komanda);

fprintf('\n Saving      done');
save_time=etime(clock,t1);
fprintf(' .... %7.2f sec',save_time);

tot_time=read_time+...
         hpfilt_time+...
         pitch_time+...
         pitch_fil_time+...
         lpc_time+...
         save_time;

fprintf('\n Total time      ');
fprintf(' .... %7.2f sec',tot_time);
