param(1)=512;     % Broj uzoraka frame-a
param(2)=110;     % korak frame-ova izrazen u broju uzoraka
param(3)=80;      % Donja granicna frekvecija u Hz (-3 dB)
param(4)=0.9375;  % faktor za pre-emphasis ili 0 ako je bez
param(5)=3e-3;    % minimalni ocekivani pitch period
param(6)=15e-3;   % maksimalni ocekivani pitch period
param(7)=0.175;   % v/uv prag
param(8)=1;       % HTP Cepstrum interpolation (1=Yes)
param(9)=1;       % Median-Linear Pitch filtering (1=Yes)
param(10)=16;     % LPC predictor order

analy('gals_moj.wav','gals_moj.mat',param,1);
load gals_moj

[bf,p] = size(a_m);
p = p-1;
a_m = a_m(:,2:p+1);
b=3;

k_m_norm = (k_m+1) / 2;

k_m_cijel=floor(k_m_norm*2^b);
k_m_norm_dek=(k_m_cijel+0.5)/(2^b);

k_m_dek=k_m_norm_dek*2 - 1;
k_m = k_m_dek; 

for i = 1 : bf
    a_m_dek(i,:) = k2a(k_m_dek(i,:));
end

a_m = a_m_dek; 
save glas_test
synt('glas_test.mat','glas_test_no.wav',1,1);
