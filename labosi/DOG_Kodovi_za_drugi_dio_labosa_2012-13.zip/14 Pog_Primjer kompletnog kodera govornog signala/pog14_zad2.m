param(1)=512;     % Broj uzoraka frame-a
param(2)=110;     % korak frame-ova izrazen u broju uzoraka
param(3)=80;      % Donja granicna frekvecija u Hz (-3 dB)
param(4)=0.9375;  % faktor za pre-emphasis ili 0 ako je bez
param(5)=3e-3;    % minimalni ocekivani pitch period
param(6)=15e-3;   % maksimalni ocekivani pitch period
param(7)=0.175;   % v/uv prag
param(8)=1;       % HTP Cepstrum interpolation (1=Yes)
param(9)=1;       % Median-Linear Pitch filtering (1=Yes)
param(10)=16;     % LPC predictor order

analy('gals_moj.wav','gals_moj.mat',param,1);
load gals_moj

[bf] = size(pp);
ppmax = max(pp);
pp_norm = pp / ppmax;
b=4;

pp_cijel=floor(pp_norm*2^b);
pp_norm_dek=(pp_cijel+0.5)/(2^b);

pp_dek=pp_norm_dek*ppmax;
pp = pp_dek; 

[bf] = size(En_m);
En_mmax = max(En_m);
En_m_norm = En_m / En_mmax;
b=4;

En_m_cijel=floor(En_m_norm*2^b);
En_m_norm_dek=(En_m_cijel+0.5)/(2^b);

En_m_dek=En_m_norm_dek*En_mmax;
En_m = En_m_dek;

save glas_test
synt('glas_test.mat','glas_test_no.wav',1,1);
