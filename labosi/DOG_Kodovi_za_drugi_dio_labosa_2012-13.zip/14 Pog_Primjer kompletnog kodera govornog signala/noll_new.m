function [en,v,pp]=noll_new(N,fs,kor,pp_mn,pp_mx,tr,koef,interp)
%function [en,v,pp]=noll_new(N,fs,kor,pp_mn,pp_mx,tr,koef,interp)
%
% Cepstrum Pitch Determination
% A. Michael Noll
% The Journal of the Acoustical Society of America
% Vol. 41, Feb 1967, 293-309
%
% ... ulaz:  dat ...... signal, kao GLOBALNA varijabla
%            N ...... broj tocaka za FFT
%            fs ..... sampling rate
%            kor .... korak za novi Frame
%            pp_mn .. minimalni pitch period (ms)
%            pp_mx .. maksimalni pitch period (ms)
%            tr ..... prag za voiced / unvoiced
%            koef ... koeficijenti polimona za HTP weighting
%            interp . ako je interp==1 radi se Cepstralna
%                     interpolacija kod trazenja maksimuma
%
% ... izlaz: v ...... binarni vektor (1=voiced, 0=unvoiced)
%            pp ..... pitch period (u broju uzoraka)
%            en ..... nulti Cepstralni uzorak (energija)

global dat;

faktor=[1/3 1/2 2/3];

% Korisne kosntante
ms_1=round(1e-3*fs);
ms_05=round(0.5e-3*fs);

% Osiguraj da pp_mn i pp_mx budu unutar intervala za
% koji je izracunat HTP weighting polinom
pp_mn=max(pp_mn,1e-3);
pp_mx=min(pp_mx,23e-3);

% Pretovri to u broj uzoraka
pp_min=floor(pp_mn*fs);
pp_max=floor(pp_mx*fs);

% To svakako mora biti unutar 0 i N/2-1, jer je inace za zadane
% fs, pp_mn i pp_mx .... broj uzoraka N u kojima se radi FFT
% krivo odabran

pp_min=max(pp_min,0);
pp_max=min(pp_max,N/2-1);

% Ovo je x-os
x=[pp_min:pp_max];

% Koristeci koef, nadji weighting funkciju
cep_lms=polyval(koef,x);

%plot(cep_lms);
%pause;

% Hammingov vremenski otvor za FFT analizu
% Oprez !!! .... ako se mijenja tip vremenskog otvora ili N
% mora se shodno tome mijenjati i weighting polinom
w=hamming(N);

% broj frame-ova za analizu
bf=floor((max(size(dat))-N)/kor)+1;

% Inicijalizacija
v=zeros(bf+2,1);
pp=zeros(bf+2,1);

%v_raw=zeros(bf,1);
%pp_raw=zeros(bf,1);

%v_int=zeros(bf,1);
%pp_int=zeros(bf,1);
%koji_int=zeros(bf,1);

en=zeros(bf,1);

pt=0;

xp_m=zeros(bf,N/2);

% Za sve frame-ove u signalu
for i=(1+2):(bf+2),

  % Uzmi N uzoraka signala pomozenih vremenskim otvorom
  s=dat((i-1-2)*kor+1:(i-1-2)*kor+N).*w';

  % Nadji Cepstrum
  xp=real(ifft(log(abs(fft(s))+1e-6)));
  xp_m(i-2,:)=xp(1:N/2);

  % Sacuvaj informaciju o energiji (nulti koeficijent
  % Cepstruma)
  en(i-2)=xp(1);

  % Pomonzi High Time Part s tezinskom funkcijom
  htp=abs(xp(pp_min+1:pp_max+1).*cep_lms);

  % Izbaci nule ... osigurava da alfa i delta ne budu
  % jednaki 0 kod Cepstralne interpolacije, sto bi
  % uzrokovalo gresku (dijeljenje s 0)

  htp=htp+1e-3;

  % Nadji najvisi siljak u HTP Cepstrum-a (iznos i poziciju)
  [vrh pitch]=max(htp);

%  pp_raw(i-2)=pitch+pp_min-1;
%  vrh_raw(i-2)=vrh;

  % Ako se radi quefrency interpolation
  if (interp==1),

  % Obrisi varijablu u koju spremamo spektralni rastav pile
  %
  rastav=[];

  % ako se nadjeni maksimum ne nalazi na samom rubu HTP
  % dijela Cepstruma, tada pogledaj koji je veci od
  % susjeda... lijevi ili desni ?

  if (pitch>1 & pitch<(pp_max-pp_min+1)),
    if (htp(pitch-1)>htp(pitch+1)),

      % ako je to lijevi susjed tada, prvi je lijevi a drugi 
      % je centralni
      l1=pitch-1;

    % inace prvi je centralni a drugi je desni
    else,
      l1=pitch;
    end;
    l2=l1+1;

    % nadji faktor delta prema formuli za interpolaciju
    alfa=htp(l2)/htp(l1);
    delta=alfa/(1+alfa);

    % Izraz za pravi quefrency najviseg harmonika
    % ... u broju uzoraka, a ne u milisec
    quef1=(l1+pp_min-1+delta);

    % ako je prvi veci od drugog po amplitudi
    %
    if (htp(l1)>htp(l2)),

      % tada koristi prvog za odredjivanje amplitude
      a1=pi*delta*htp(l1)/abs(sin(pi*delta));

    %   inace koristi drugog
    else,
      a1=pi*(1-delta)*htp(l2)/abs(sin(pi*(1-delta)));
    end;

    % upisi nadjene podatke u tabelu rastava
    %
    rastav(1,:)=[1 quef1 a1];

    % Sada jos obavi posao na sub-rahmonicima
    % nadjenog pitch-a

    for ii=1:max(size(faktor)),

      % odredi pojas u kojem trazimo maksimum
      low=round(quef1*faktor(ii)-ms_05);
      hig=round(quef1*faktor(ii)+ms_05);

      % ako se taj pojas nalazi unutar HTP Cepstrum-a
      if(low>pp_min & hig<pp_max),

        % nadji poziciju prvog maksimuma u tom pojasu
        [vhr_ra pitch_ra]=max(htp(low-pp_min+1:hig-pp_min+1));
        pitch_ra=pitch_ra+low-pp_min;

        % odredi koji od susjednih je veci pa prema tome
        % odaberi par spektralnih uzoraka

	if (htp(pitch_ra-1)>htp(pitch_ra+1)),
	   l1=pitch_ra-1;
	   l2=pitch_ra;
	else,
	   l1=pitch_ra;
	   l2=pitch_ra+1;
	end;

        % odredi faktor delta

	alfa=htp(l2)/htp(l1);
	delta=alfa/(1+alfa);

        % Izraz za pravi quefrency sub-rahmonika
        % ... u broju uzoraka, a ne u milisec
        quefi=(l1+pp_min-1+delta);

        % ako je prvi veci od drugog po amplitudi
        %
        if (htp(l1)>htp(l2)),

            % tada koristi prvog za odredjivanje amplitude
            ai=pi*delta*htp(l1)/abs(sin(pi*delta));

        % inace koristi drugog
        else,
            ai=pi*(1-delta)*htp(l2)/abs(sin(pi*(1-delta)));
        end;

        % upisi u tablicu rastava
        rastav((ii+1),:)=[faktor(ii) quefi ai];

      % ... inace, ako se pod-rahminici ne nalaze unutar
      % HTP dijela upisi 0 u tablicu rastava
      else,
        rastav((ii+1),:)=[faktor(ii) 0 0];
      end;
    end;

  % ... inace ako se osnovi harmonik nalazi na rubovima
  % HTP dijela, tada jednostavno uzmi ono sto se dobiva
  % kao maksimum bez ikakve interpolacije
  else,
    rastav(1,:)=[1 pitch+pp_min-1 vrh];
    rastav(2:max(size(faktor))+1,:)=...
      zeros(max(size(faktor)),3);
  end;
  
  % Nakon uspjesno provedenog rastava, potrebno je naci
  % koji od rahmonika ima najvecu amplitudu
  [vrh_rah koji_rah]=max(rastav(:,3));

%  vrh_int(i-2)=vrh_rah;
%  pp_int(i-2)=rastav(koji_rah,2);
%  koji_int(i-2)=koji_rah;

  vrh=vrh_rah;
  pitch=rastav(koji_rah,2);

  % Inace ako se ne radi Cepstralna interpolacija
  else,
    % Pretvori relativnu poziciju u apsolutnu
    pitch=pitch+pp_min-1;
  end;

%  disp([vrh pitch]);
%  disp(rastav);
%  fprintf('\n --------------------');

  % Upisi nadjeni pitch period u vektor pp
  pp(i)=pitch;

  % Podesi prag na zadanu vrijednost
  prg=tr;

  % Ako smo u modu ptich tracking-a
  if (pt==1),
    % ... i ako je razlika pp-a prema proslom frame-u manja
    %     ili jedanaka 1 ms, tada smanji prag na pola
    if (abs(pitch-pp(i-1))<=ms_1),
       prg=tr/2;
    end;
  end;

% Provjeri da li je doslo do udvostrucenja PITCH-a

  % Ako smo u modu ptich tracking-a,
  if (pt==1),

     % i ako je trenutni pitch vise nego 1.6 puta veci
     % od predhodnog
     if (pitch/(pp(i-1))>=1.6),

        % definiraj sub-interval +/- 0.5 ms oko polovine
        % nadjenog pitch perioda
        si_pp_min=floor(pitch/2)-ms_05;
        si_pp_max=floor(pitch/2)+ms_05;

        % te, ako je taj interval poskup originalnog HTP intervala
        if (si_pp_min>=pp_min & si_pp_max<=pp_max),

            % izdovji taj interval
            si_htp=htp(si_pp_min-pp_min+1:si_pp_max-pp_min+1);

            % i nadji poziciju i iznos maksimuma unutar tog
            % sub-intervala
            [vrh2 pitch2]=max(si_htp);
            pitch2=pitch2+si_pp_min-1;

            % podesi prag na inicijalnu vrijednost
            prg2=tr;

            % ako je razlika pitch2 prema proslom frame-u manja ili
            % jedanaka 1 ms, tada smanji prag na pola
            if (abs(pitch2-pp(i-1))<=ms_1),
              prg2=tr/2;
            end;

            % Ako je vrh iznad tako definiranog praga
            if (vrh2>prg2),

              % .... taj novi (duplo manji) pitch upisi u pp
              pp(i)=pitch2;

              % i oznaci zvucni segement
              v(i)=1;
            end;
        end;
     end;
  end;

  % Ako se originalno nadjeni vrh nalazi iznad praga
  if (vrh>prg),

     % preliminarno oznaci voiced segment
     v(i)=1;

     % ako je i prosli segment bio voiced
     if (v(i-1)==1),

       % aktiviraj pitch tracking
       pt=1;

     % inace ako je ovaj voiced a prosli unvoiced, tada provjeri i
     % pretprosli
     else,

       % ako je on takodjer voiced, tada je ovaj prosli segment
       % jedan izolirani unvoiced segment izmedju dva voiced
       if (v(i-2)==1),

         % tada i taj prosli proglasi voiced segmentom, a kao
         % pitch period odaberi srednju vrijednost ovog i
         % pretproslog segmenta
         pp(i-1)=(pp(i)+pp(i-2))/2;
         v(i-1)=1;
       end;
     end;

% .... inace ako se maksimum nalazi ispod praga (pretpostavka da
% je rijec o un-voiced segmentu)
  else,

     % provjeri da li je prosli bio voiced
     if (v(i-1)==1),

       % i da li je pretprosli takodjer voiced
       if (v(i-2)==1),

           % ... u tom slucaju, nakon dva voiced intervala
           % pojavio se jedan unvoiced, pa ugasi pitch tracking
           pt=0;

       % .... ako su trenutni i pretprosli unvoiced, a prosli
       % voiced, tada i taj prosli pretvori u unvoiced
       % (radi se o izoliranom pitch peak-u)
       else,
           v(i-1)=0;
       end;
     end;
  end;

% kraj for petlje

end;

%plot(abs(xp_m')+([1:bf]'/10*ones(1,N/2))')
%pause;

%keyboard;

% Makni pocetne uvjete za v i pp

v([1 2])=[];
pp([1 2])=[];