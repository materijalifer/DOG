function a=k2a(k)
%function a=k2a(k)
%
% Funkcija koja pretvara "k" (PARCOR) parametre LPC filtra u 
% "a" parametre LPC polinoma p-tog stupnja  s p+1 elemenata od 
% kojih je prvi jednak 1
%
p=max(size(k));
alf=diag(k);
for i=2:p,
  alf(i,1:i-1)=alf(i-1,1:i-1)+alf(i,i)*alf(i-1,i-1:-1:1);
end;
a=[1 alf(p,:)];
